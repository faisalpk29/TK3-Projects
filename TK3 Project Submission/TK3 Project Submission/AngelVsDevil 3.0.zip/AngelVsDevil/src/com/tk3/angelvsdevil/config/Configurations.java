package com.tk3.angelvsdevil.config;

import java.util.HashMap;
import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import com.tk3.angelvsdevil.R;

public class Configurations {
	public static boolean IsDevil = false;

	public static final int S_punch = R.raw.punch;
	public static final int S_punch_final = R.raw.punch_final;
	public static final int S_knife_sharpening = R.raw.knife_sharpening;
	public static final int S_knife_attack = R.raw.knife_attack;
	public static final int S_knife_stab = R.raw.knife_stab;
	public static final int S_sword1 = R.raw.sword1;
	public static final int S_sword2 = R.raw.sword2;
	public static final int S_sword3 = R.raw.sword3;

	public static final int S_soundtrack = R.raw.soundtrack;

	public static int health = 100;
	public static int enemy_health = 100;
	public static int stamina = 100;
	public static boolean winner = false;

	private static SoundPool soundPool;
	private static HashMap<Integer, Integer> soundPoolMap;

	/** Play a given sound in the soundPool */
	public static void playSound(Context context, int soundID) {
		if (soundPool == null || soundPoolMap == null) {
			initSounds(context);
		}
		float volume = (float) 1.0;// whatever in the range = 0.0 to 1.0

		// play sound with same right and left volume, with a priority of 1,
		// zero repeats (i.e play once), and a playback rate of 1f
		soundPool.play((Integer) soundPoolMap.get(soundID), volume, volume, 1,
				0, 1f);
	}

	/** Play the sound using android.media.MediaPlayer */
	public static void playSoundMP(Context context, int soundID) {
		MediaPlayer mp = MediaPlayer.create(context, soundID);
		mp.setLooping(true);
		mp.setVolume(0.1f, 0.1f);
		mp.start();
	}

	/** Populate the SoundPool */
	@SuppressLint("UseSparseArrays")
	public static void initSounds(Context context) {
		soundPool = new SoundPool(2, AudioManager.STREAM_MUSIC, 100);
		soundPoolMap = new HashMap<Integer, Integer>(3);

		soundPoolMap.put(S_punch, soundPool.load(context, R.raw.punch, 1));
		soundPoolMap.put(S_punch_final,
				soundPool.load(context, R.raw.punch_final, 2));
		soundPoolMap.put(S_knife_sharpening,
				soundPool.load(context, R.raw.knife_sharpening, 3));
		soundPoolMap.put(S_knife_attack,
				soundPool.load(context, R.raw.knife_attack, 4));
		soundPoolMap.put(S_knife_stab,
				soundPool.load(context, R.raw.knife_stab, 5));
		soundPoolMap.put(S_sword1, soundPool.load(context, R.raw.sword1, 6));
		soundPoolMap.put(S_sword2, soundPool.load(context, R.raw.sword2, 7));
		soundPoolMap.put(S_sword3, soundPool.load(context, R.raw.sword3, 8));
		soundPoolMap.put(S_soundtrack,
				soundPool.load(context, R.raw.soundtrack, 8));
	}
}
