package com.tk3.angelvsdevil.config;

public class GesturesConstants {
	public static final int KNIFE = 1;
	public static final int SWORD = 2;
	public static final int PUNCH = 3;
	public static final int DEFENCE = 4;
	
	
	public static final int ISPLAYERDEVIL = 8;
	
	
}
