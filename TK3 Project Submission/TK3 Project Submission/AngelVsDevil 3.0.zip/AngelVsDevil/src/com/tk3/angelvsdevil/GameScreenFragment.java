package com.tk3.angelvsdevil;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tk3.angelvsdevil.communication.MessageManager;
import com.tk3.angelvsdevil.config.ActivateShieldEnemy;
import com.tk3.angelvsdevil.config.ActivateShieldSelf;
import com.tk3.angelvsdevil.config.Configurations;
import com.tk3.angelvsdevil.config.GesturesConstants;
import com.tk3.angelvsdevil.config.PlayerStatus;

/**
 * This fragment handles chat related Game Play UI which includes a progress
 * bars, stamina bar and different gifs based on user moves.
 */
public class GameScreenFragment extends Fragment {

	CustomGifView gifViewEnemyMove, gifViewMyMove, gifViewEnemy, gifViewMy;
	ProgressBar ProgressBarHMe;
	ProgressBar ProgressBarHEnemy;
	ProgressBar StaminaMe;
	Button buttonDefence;

	private View view;
	public MessageManager messageManager;

	private final long startTime = 1000;
	private final long interval = 1000;
	private CustomTimer countDownTimer;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		view = inflater.inflate(R.layout.game_screen, container, false);
		gifViewEnemy = (CustomGifView) view.findViewById(R.id.img_enemy_gif);
		gifViewEnemyMove = (CustomGifView) view
				.findViewById(R.id.img_enemy_move_gif);
		gifViewMy = (CustomGifView) view.findViewById(R.id.img_my_gif);
		gifViewMyMove = (CustomGifView) view.findViewById(R.id.img_my_move_gif);
		countDownTimer = new CustomTimer(startTime, interval);

		if (Configurations.IsDevil) {

			gifViewMy.nextWeapon(R.drawable.devil);
			gifViewEnemy.nextWeapon(R.drawable.angel);
		} else {
			gifViewMy.nextWeapon(R.drawable.angel);
			gifViewEnemy.nextWeapon(R.drawable.devil);

		}

		gifViewEnemyMove.setVisibility(View.INVISIBLE);
		gifViewMyMove.setVisibility(View.INVISIBLE);

		ProgressBarHMe = (ProgressBar) view
				.findViewById(R.id.progressbar_Horizontal_me);
		ProgressBarHEnemy = (ProgressBar) view
				.findViewById(R.id.progressbar_Horizontal_enemy);
		StaminaMe = (ProgressBar) view.findViewById(R.id.ProgressBarStamina);
		ProgressBarHMe.setProgress(0);
		ProgressBarHEnemy.setProgress(0);
		StaminaMe.setProgress(0);

		buttonDefence = (Button) view.findViewById(R.id.buttonDefence);

		buttonDefence.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				messageManager.write((GesturesConstants.DEFENCE + "")
						.toString().getBytes());
				pushMessage("Me: " + GesturesConstants.DEFENCE);
				new ActivateShieldSelf().execute("");
			}

		});

		TextView text1 = (TextView) view.findViewById(R.id.textViewMyName);
		text1.setTextColor(Color.parseColor("#ff0000ff"));
		TextView text2 = (TextView) view.findViewById(R.id.textViewEnemyName);
		text2.setTextColor(Color.parseColor("#ffff0000"));
		TextView textViewStamina = (TextView) view
				.findViewById(R.id.textViewStamina);
		textViewStamina.setTextColor(Color.parseColor("#ff888888"));
		updateProgressBars();
		return view;
	}

	public interface MessageTarget {
		public Handler getHandler();
	}

	public void setChatManager(MessageManager obj) {
		messageManager = obj;
	}

	/**
	 * Handles our communication messages
	 * 
	 * @param readMessage
	 */
	public void pushMessage(String readMessage) {
		// Message Recieved
		handleMessage(readMessage);
	}

	private void handleMessage(String message) {

		boolean isMe = true;

		if (message.startsWith("Me: ")) {
			isMe = true;
			message = message.replace("Me: ", "");
		} else {
			isMe = false;
			message = message.replace("Buddy: ", "");
		}

		// Toast.makeText(getActivity().getApplicationContext(), message,
		// Toast.LENGTH_SHORT).show();

		if (!isMe && Integer.parseInt(message) == GesturesConstants.DEFENCE) {
			new ActivateShieldEnemy().execute("");
		}

		if (!isMe) {

			if (!PlayerStatus.SELF_DEFENCE) {

				gifViewEnemyMove.setVisibility(View.VISIBLE);
				countDownTimer.start();
				switch (Integer.parseInt(message)) {

				case GesturesConstants.KNIFE:

					Configurations.playSound(getActivity()
							.getApplicationContext(),
							Configurations.S_knife_stab);

					Configurations.health -= 3;
					gifViewEnemyMove.nextWeapon(R.drawable.knife_ranger);
					updateProgressBars();
					break;

				case GesturesConstants.SWORD:

					Configurations.playSound(getActivity()
							.getApplicationContext(), Configurations.S_sword2);
					Configurations.health -= 5;
					gifViewEnemyMove.nextWeapon(R.drawable.samurai_sword_swing);
					updateProgressBars();
					break;

				case GesturesConstants.PUNCH:

					Configurations.playSound(getActivity()
							.getApplicationContext(),
							Configurations.S_punch_final);
					Configurations.health -= 2;
					gifViewEnemyMove.nextWeapon(R.drawable.punch);
					updateProgressBars();
					break;

				case GesturesConstants.DEFENCE:

					gifViewEnemyMove.nextWeapon(R.drawable.shield);
					updateProgressBars();
					break;

				case GesturesConstants.ISPLAYERDEVIL:

					gifViewEnemy.nextWeapon(R.drawable.devil);
					updateProgressBars();
					break;

				default:
					break;
				}
			}
		} else {

			updateProgressBars();

			gifViewMyMove.setVisibility(View.VISIBLE);

			countDownTimer.start();

			switch (Integer.parseInt(message)) {

			case GesturesConstants.KNIFE:
				gifViewMyMove.nextWeapon(R.drawable.knife_ranger);
				Configurations.stamina -= 10;

				if (!PlayerStatus.ENEMY_DEFENCE)
					Configurations.enemy_health -= 3;

				updateProgressBars();
				break;

			case GesturesConstants.SWORD:
				gifViewMyMove.nextWeapon(R.drawable.samurai_sword_swing);
				Configurations.stamina -= 10;

				if (!PlayerStatus.ENEMY_DEFENCE)
					Configurations.enemy_health -= 5;

				updateProgressBars();
				break;

			case GesturesConstants.PUNCH:
				gifViewMyMove.nextWeapon(R.drawable.punch);
				Configurations.stamina -= 10;

				if (!PlayerStatus.ENEMY_DEFENCE)
					Configurations.enemy_health -= 2;

				updateProgressBars();
				break;

			case GesturesConstants.DEFENCE:
				gifViewMyMove.nextWeapon(R.drawable.shield);
				Configurations.playSound(getActivity().getApplicationContext(),
						Configurations.S_sword1);
				// Configurations.stamina += 10;
				// Configurations.enemy_health += 2;
				updateProgressBars();
				break;

			default:
				break;
			}
		}

	}

	/**
	 * update progress bars
	 */
	private void updateProgressBars() {
		if (Configurations.stamina <= 0) {
			new UpdateProgressAsyncTask().execute();
		}
		if (Configurations.enemy_health <= 0) {
			Toast.makeText(getActivity(), "You Win", Toast.LENGTH_LONG).show();

			new AlertDialog.Builder(getActivity())
					.setTitle("You Win !")
					.setMessage("Thank you for playing Angel Vs Devil")
					.setPositiveButton("Restart?",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {

									Configurations.health = 100;
									Configurations.enemy_health = 100;
									Configurations.stamina = 100;
									Configurations.winner = false;
									updateProgressBars();
								}
							})
					.setNegativeButton("Quit",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									getActivity().finish();
									System.exit(0);
								}
							}).setIcon(android.R.drawable.ic_dialog_alert)
					.show();

		}

		else if (Configurations.health <= 0) {
			Toast.makeText(getActivity(), "You lose", Toast.LENGTH_LONG).show();

			new AlertDialog.Builder(getActivity())
					.setTitle("You Lose !")
					.setMessage("Thank you for playing Angel Vs Devil")
					.setPositiveButton("Restart?",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {

									Configurations.health = 100;
									Configurations.enemy_health = 100;
									Configurations.stamina = 100;
									Configurations.winner = false;
									updateProgressBars();
								}
							})
					.setNegativeButton("Quit",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									getActivity().finish();
									System.exit(0);
								}
							}).setIcon(android.R.drawable.ic_dialog_alert)
					.show();

		} else {
			new UpdateProgressAsyncTask().execute();
		}
	}

	/**
	 * Async Task which updates the progress bars.
	 *
	 * @author AbdulRehman
	 *
	 */
	public class UpdateProgressAsyncTask extends AsyncTask<Void, Integer, Void> {

		int myProgress;

		@Override
		protected void onPostExecute(Void result) {
		}

		@Override
		protected void onPreExecute() {
			myProgress = 0;
		}

		@Override
		protected Void doInBackground(Void... params) {

			publishProgress();
			return null;
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			ProgressBarHMe.setProgress(Configurations.health);
			ProgressBarHEnemy.setProgress(Configurations.enemy_health);
			StaminaMe.setProgress(Configurations.stamina);
		}

	}

	public class CustomTimer extends CountDownTimer {

		public CustomTimer(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
		}

		@Override
		public void onTick(long millisUntilFinished) {
		}

		@Override
		public void onFinish() {

			gifViewMyMove.setVisibility(View.INVISIBLE);
			gifViewEnemyMove.setVisibility(View.INVISIBLE);
			this.cancel();

		}
	}

}
