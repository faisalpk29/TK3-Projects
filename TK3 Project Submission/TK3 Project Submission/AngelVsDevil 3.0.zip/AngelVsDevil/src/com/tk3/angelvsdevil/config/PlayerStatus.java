package com.tk3.angelvsdevil.config;

public class PlayerStatus {
	public static boolean SELF_DEFENCE = false;
	public static boolean ENEMY_DEFENCE = false;
}
