package com.tk3.angelvsdevil.config;

import android.os.AsyncTask;

/**
 * Created by AbdulRehman on 6/24/2015.
 */
public class ActivateShieldSelf extends AsyncTask<String, Void, String> {

	@Override
	protected void onPreExecute() {
		if(!PlayerStatus.SELF_DEFENCE && Configurations.stamina <= 90)
			Configurations.stamina += 10;
		
		PlayerStatus.SELF_DEFENCE = true;
		
	}
	
	@Override
	protected String doInBackground(String... params) {
		String errorr = "";
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return errorr;
	}

	@Override
	protected void onPostExecute(String result) {
		PlayerStatus.SELF_DEFENCE = false;
	}



	@Override
	protected void onProgressUpdate(Void... values) {
	}
}