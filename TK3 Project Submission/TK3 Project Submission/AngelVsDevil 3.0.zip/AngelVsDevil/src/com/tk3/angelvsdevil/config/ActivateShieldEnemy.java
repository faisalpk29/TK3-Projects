package com.tk3.angelvsdevil.config;

import android.os.AsyncTask;

/**
 * Created by AbdulRehman on 6/24/2015.
 */
public class ActivateShieldEnemy extends AsyncTask<String, Void, String> {

	@Override
	protected void onPreExecute() {
		PlayerStatus.ENEMY_DEFENCE = true;
	}
	
	@Override
	protected String doInBackground(String... params) {
		String errorr = "";
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return errorr;
	}

	@Override
	protected void onPostExecute(String result) {
		PlayerStatus.ENEMY_DEFENCE = false;
	}



	@Override
	protected void onProgressUpdate(Void... values) {
	}
}