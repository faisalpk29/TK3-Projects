package com.tk3.angelvsdevil;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.tk3.angelvsdevil.communication.WiFiServiceDiscoveryActivity;
import com.tk3.angelvsdevil.config.GesturesConstants;
import com.tk3.angelvsdevil.gestures.IGestureRecognitionListener;
import com.tk3.angelvsdevil.gestures.IGestureRecognitionService;
import com.tk3.angelvsdevil.gestures.classifier.Distribution;

public class TrainingWindowActivity extends Activity {

	CustomGifView gifView;
	Button btnStartTraining;
	Button btnStopTraining;
	TextView txtWeaponToTrain;
	private int weaponId = GesturesConstants.SWORD;

	private CustomTimer countDownTimer;

	private final long startTime = 5000;
	private final long interval = 1000;

	IGestureRecognitionService recognitionService;
	String activeGestureName;
	int activeGesture;

	private final ServiceConnection serviceConnection = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName className, IBinder service) {
			recognitionService = IGestureRecognitionService.Stub
					.asInterface(service);
			try {
				recognitionService.startClassificationMode("default");
				recognitionService
						.registerListener(IGestureRecognitionListener.Stub
								.asInterface(gestureListenerStub));
			} catch (RemoteException e1) {
				e1.printStackTrace();
			}
		}

		@Override
		public void onServiceDisconnected(ComponentName className) {
			recognitionService = null;
		}
	};
	IBinder gestureListenerStub = new IGestureRecognitionListener.Stub() {

		@Override
		public void onGestureLearned(String gestureName) throws RemoteException {

			String tPrint = "";

			switch (Integer.parseInt(gestureName)) {
			case GesturesConstants.KNIFE:
				tPrint = "KNIFE";
				break;
			case GesturesConstants.PUNCH:
				tPrint = "PUNCH";
				break;
			case GesturesConstants.SWORD:
				tPrint = "SWORD";
				break;
			case GesturesConstants.DEFENCE:
				tPrint = "DEFENCE";
				break;
			default:
				tPrint = "Unknown Gesture";
				break;
			}

			Toast.makeText(getApplicationContext(),
					String.format("Gesture %s learned", tPrint),
					Toast.LENGTH_SHORT).show();
			System.err.println("Gesture %s learned");

			recognitionService.stopLearnMode();
			btnStartTraining.setText("Start Training");
		}

		@Override
		public void onTrainingSetDeleted(String trainingSet)
				throws RemoteException {
			Toast.makeText(getApplicationContext(),
					String.format("Training set %s deleted", trainingSet),
					Toast.LENGTH_SHORT).show();
			System.err.println(String.format("Training set %s deleted",
					trainingSet));
		}

		@Override
		public void onGestureRecognized(final Distribution distribution)
				throws RemoteException {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {

					if (distribution.getBestDistance() <= 12) {

						String tPrint = "";

						switch (Integer.parseInt(distribution.getBestMatch())) {
						case GesturesConstants.KNIFE:
							tPrint = "KNIFE";
							break;
						case GesturesConstants.PUNCH:
							tPrint = "PUNCH";
							break;
						case GesturesConstants.SWORD:
							tPrint = "SWORD";
							break;
						case GesturesConstants.DEFENCE:
							tPrint = "DEFENCE";
							break;
						default:
							tPrint = "Unknown Gesture";
							break;

						}

						Toast.makeText(getApplicationContext(),
								String.format("%s", tPrint),

								Toast.LENGTH_SHORT).show();
					}
					System.err.println(String.format("%s: %f",
							distribution.getBestMatch(),
							distribution.getBestDistance()));
				}
			});
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.training_window);

		countDownTimer = new CustomTimer(startTime, interval);

		activeGestureName = "knife";
		activeGesture = GesturesConstants.KNIFE;

		final SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar2);
		seekBar.setVisibility(View.INVISIBLE);
		seekBar.setMax(20);
		seekBar.setProgress(20);
		seekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {

				try {
					recognitionService.setThreshold(progress / 10.0f);
				} catch (RemoteException e) {
					e.printStackTrace();
				}

			}
		});

		final Button btnSettings = (Button) findViewById(R.id.btnNew);
		btnSettings.setOnClickListener(listener);

		try {
			gifView = (CustomGifView) findViewById(R.id.imgWeapon);
			btnStartTraining = (Button) findViewById(R.id.btnStartTraining);
			btnStopTraining = (Button) findViewById(R.id.btnStopTraining);
			txtWeaponToTrain = (TextView) findViewById(R.id.txtWeaponToTrain);
			txtWeaponToTrain.setText(" Knife ");
			btnStartTraining.setOnClickListener(listener);
			btnStopTraining.setOnClickListener(listener);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	View.OnClickListener listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {

			switch (v.getId()) {
			case R.id.btnStartTraining: {

				if (recognitionService != null) {
					try {
						if (!recognitionService.isLearning()) {
							btnStartTraining.setText("Stop Training");

							recognitionService.startLearnMode("default",
									activeGesture + "");
						} else {
							btnStartTraining.setText("Start Training");
							recognitionService.stopLearnMode();
						}
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}

				break;
			}

			case R.id.btnStopTraining: {

				switch (weaponId) {
				case GesturesConstants.KNIFE:
					countDownTimer.start();
					gifView.setVisibility(View.VISIBLE);
					activeGestureName = "knive";
					activeGesture = GesturesConstants.KNIFE;

					txtWeaponToTrain.setText("Knive");
					gifView.nextWeapon(R.drawable.knife_ranger);
					break;
				case GesturesConstants.SWORD:
					countDownTimer.start();
					gifView.setVisibility(View.VISIBLE);
					activeGestureName = "sword";
					activeGesture = GesturesConstants.SWORD;

					txtWeaponToTrain.setText("Sword");
					gifView.nextWeapon(R.drawable.samurai_sword_swing);
					break;
				case GesturesConstants.PUNCH:
					countDownTimer.start();
					gifView.setVisibility(View.VISIBLE);
					activeGestureName = "punch";
					activeGesture = GesturesConstants.PUNCH;
					txtWeaponToTrain.setText("Punch");
					gifView.nextWeapon(R.drawable.daggerspin_hw);
					break;
				case GesturesConstants.DEFENCE:
					countDownTimer.start();
					gifView.setVisibility(View.VISIBLE);
					activeGestureName = "Defence";
					activeGesture = GesturesConstants.DEFENCE;
					txtWeaponToTrain.setText("Defence");
					gifView.nextWeapon(R.drawable.shield);
					weaponId = 0;
					break;
				case 5:
					weaponId = 0;
					break;
				default:
					break;

				}
				weaponId++;
				break;
			}
			case R.id.btnNew:
				Intent intent = new Intent(getApplicationContext(),
						WiFiServiceDiscoveryActivity.class);
				startActivity(intent);
				break;

			default:
				break;
			}
		}
	};

	@Override
	protected void onPause() {
		try {
			recognitionService
					.unregisterListener(IGestureRecognitionListener.Stub
							.asInterface(gestureListenerStub));
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		recognitionService = null;
		unbindService(serviceConnection);
		super.onPause();
	}

	@Override
	protected void onResume() {
		Intent bindIntent = new Intent(
				"com.tk3.angelvsdevil.gestures.GESTURE_RECOGNIZER");
		bindService(bindIntent, serviceConnection, Context.BIND_AUTO_CREATE);
		super.onResume();
	}

	public class CustomTimer extends CountDownTimer {

		public CustomTimer(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.os.CountDownTimer#onTick(long)
		 */
		@Override
		public void onTick(long millisUntilFinished) {

		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.os.CountDownTimer#onFinish()
		 */
		@Override
		public void onFinish() {

			this.cancel();

		}
	}

}
